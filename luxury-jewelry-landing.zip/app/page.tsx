"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ShoppingBag, Crown, Shield, Truck, Watch, Cross, Sparkles } from "lucide-react"

export default function LuxuryJewelryLanding() {
  return (
    <div className="min-h-screen bg-slate-900 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"></div>
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl"></div>
        <div className="absolute top-1/4 right-0 w-80 h-80 bg-amber-400/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-1/3 w-72 h-72 bg-amber-600/8 rounded-full blur-3xl"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(251,191,36,0.03),transparent_50%)]"></div>
      </div>
      <div className="relative z-10">
        {/* Header */}
        <header className="border-b border-slate-700 bg-slate-900/90 backdrop-blur-md sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Crown className="h-8 w-8 text-amber-400" />
              <h1 className="text-2xl font-bold text-white">SHANY SHAINS</h1>
            </div>
            <nav className="hidden md:flex items-center gap-8">
              <a href="#productos" className="text-slate-200 hover:text-amber-400 transition-colors duration-300">
                Productos
              </a>
              <a href="#relojes" className="text-slate-200 hover:text-amber-400 transition-colors duration-300">
                Relojes Rolex
              </a>
              <a href="#rosarios" className="text-slate-200 hover:text-amber-400 transition-colors duration-300">
                Rosarios
              </a>
              <a href="#bano-oro" className="text-slate-200 hover:text-amber-400 transition-colors duration-300">
                Baño en Oro 18K
              </a>
              <a href="#nosotros" className="text-slate-200 hover:text-amber-400 transition-colors duration-300">
                Nosotros
              </a>
              <a href="#contacto" className="text-slate-200 hover:text-amber-400 transition-colors duration-300">
                Contacto
              </a>
            </nav>
            <Button className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 transition-all duration-300 shadow-xl hover:shadow-amber-500/40 hover:rotate-1">
              <ShoppingBag className="h-4 w-4 mr-2" />
              Comprar
            </Button>
          </div>
        </header>

        {/* Hero Section */}
        <section className="relative py-20 lg:py-32 overflow-hidden">
          <div className="container mx-auto px-4 relative z-10">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="space-y-4">
                  <Badge className="bg-amber-500 text-slate-900 font-semibold animate-pulse">Joyería Premium</Badge>
                  <h2 className="text-4xl lg:text-6xl font-bold text-white leading-tight text-balance">
                    Elegancia en <span className="text-amber-400 animate-pulse">Oro Puro</span> y también en Baños de
                    Oro 18K
                  </h2>
                  <p className="text-xl text-slate-300 leading-relaxed text-pretty">
                    Descubre nuestra exclusiva colección de cadenas, pulseras de oro, gorras premium, relojes Rolex,
                    rosarios en oro laminado y nuestra nueva línea de baño en oro 18K. Cada pieza está diseñada para el
                    hombre moderno que valora la calidad y el estilo.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    size="lg"
                    className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-1 transition-all duration-300 shadow-xl hover:shadow-amber-500/50"
                  >
                    Ver Colección
                  </Button>
                </div>
                <div className="flex flex-col items-center gap-4"></div>
              </div>
              <div className="relative">
                <div className="aspect-square bg-gradient-to-br from-amber-400/20 to-amber-600/20 rounded-full p-8 animate-pulse">
                  <img
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/shiny%20foto%20logo-lxjoppAtIeVQ3AjhZKSFokis53szDV.png"
                    alt="SHINY CHAINS Jewelry Logo"
                    className="w-full h-full object-contain rounded-full"
                  />
                </div>
                <div className="absolute -top-4 -right-4 bg-amber-500 text-slate-900 px-4 py-2 rounded-full font-semibold animate-bounce">
                  Oro 18K
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-16 bg-slate-800/50">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto">
                  <Shield className="h-8 w-8 text-amber-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Garantía de Calidad</h3>
                <p className="text-slate-300">Oro certificado 18K con garantía de por vida</p>
              </div>
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto">
                  <Truck className="h-8 w-8 text-amber-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Envío Gratis</h3>
                <p className="text-slate-300">Si compras más de 2 accesorios</p>
              </div>
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto">
                  <Crown className="h-8 w-8 text-amber-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Diseño Exclusivo</h3>
                <p className="text-slate-300">Piezas únicas diseñadas para destacar</p>
              </div>
            </div>
          </div>
        </section>

        {/* Baño en Oro 18K Section */}
        <section id="bano-oro" className="py-20 bg-slate-800/20">
          <div className="container mx-auto px-4">
            <div className="text-center space-y-4 mb-16">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Sparkles className="h-8 w-8 text-amber-400 animate-pulse" />
                <Badge className="bg-gradient-to-r from-amber-500 to-amber-600 text-slate-900 text-lg px-4 py-2 font-semibold animate-pulse">
                  Baño en Oro 18K
                </Badge>
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold text-white text-balance">Colección Baño en Oro 18K</h2>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto text-pretty">
                Descubre nuestra exclusiva línea de cadenas y collares con baño en oro 18K. Múltiples dijes religiosos y
                diseños únicos que combinan fe, elegancia y lujo excepcional.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Cadenas Dijes Variados */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/cadenas-dijes-variados-oro-18k.jpg"
                      alt="Cadenas con Dijes Variados"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Cadenas Dijes Variados</h3>
                      <p className="text-slate-300">Set de cadenas con cruz, medalla, trébol y osito en oro 18K</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Múltiples Cadenas Religiosas */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/multiples-cadenas-religiosas-oro-18k.jpg"
                      alt="Múltiples Cadenas Religiosas"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Múltiples Cadenas Religiosas</h3>
                      <p className="text-slate-300">Colección de cadenas con cruces, vírgenes y medallas sagradas</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Set Dijes Diversos */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/set-dijes-diversos-oro-18k.jpg"
                      alt="Set Dijes Diversos"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Set Dijes Diversos</h3>
                      <p className="text-slate-300">Cadenas con corazón, cruz ornamentada, árbol de la vida y más</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Cadenas Náuticas y Religiosas */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/cadenas-nauticas-religiosas-oro-18k.jpg"
                      alt="Cadenas Náuticas y Religiosas"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Cadenas Náuticas Religiosas</h3>
                      <p className="text-slate-300">Set con ancla, cruz, santo en círculo y elementos náuticos</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Cadenas Cubanas con Diamantes */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/cadenas-cubanas-diamantes-oro-18k.jpg"
                      alt="Cadenas Cubanas con Diamantes"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Cadenas Cubanas Diamantes</h3>
                      <p className="text-slate-300">Cadenas cubanas gruesas con incrustaciones de diamantes</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Set Cadenas Religiosas Premium */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-08-29%20a%20las%2017.20.56_2aba252c.jpg-DzTK6ddorcLaNYndtG32xR1jDldlzG.jpeg"
                      alt="Set Cadenas Religiosas Premium"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Set Cadenas Religiosas Premium</h3>
                      <p className="text-slate-300">Múltiples cadenas con vírgenes, medallas y cruces en oro 18K</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Cadenas con Dijes Islámicos */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-08-29%20a%20las%2017.20.55_7b5d6fab.jpg-kQE8Bpo8oMyimeEDfrpY9eUBN0hDXG.jpeg"
                      alt="Cadenas con Dijes Islámicos"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Cadenas Dijes Islámicos</h3>
                      <p className="text-slate-300">Set con vírgenes, medallas islámicas y elementos religiosos</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Cadenas Cubanas Multicolor */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-08-29%20a%20las%2017.20.58_2e583ed5.jpg-Mr7z2VWqUVFJFA1JgNQZhlh6ErmxZW.jpeg"
                      alt="Cadenas Cubanas Multicolor"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Cadenas Cubanas Multicolor</h3>
                      <p className="text-slate-300">Cadenas cubanas con cierres de colores y acabado premium</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Set Cadenas Religiosas Múltiples */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-08-29%20a%20las%2017.20.57_ffcfb5d4.jpg-TwIsyR9tDwHj45X43mNQt2gyODIzOD.jpeg"
                      alt="Set Cadenas Religiosas Múltiples"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Set Cadenas Religiosas Múltiples</h3>
                      <p className="text-slate-300">Colección con cruces ornamentadas y medallas sagradas</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Cadenas con Dijes Únicos */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-08-29%20a%20las%2017.20.55_47c76e87.jpg-CFyrJRt7MAT04EMa2uxheMf6xS6nKe.jpeg"
                      alt="Cadenas con Dijes Únicos"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Cadenas Dijes Únicos</h3>
                      <p className="text-slate-300">Set con búho, vírgenes y elementos decorativos especiales</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Cadenas con Medallas Religiosas */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-08-29%20a%20las%2017.20.56_bf0d82b7.jpg-X3nMhqR9a0gtOIS0cv7J6n9qVkRaX7.jpeg"
                      alt="Cadenas con Medallas Religiosas"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Cadenas Medallas Religiosas</h3>
                      <p className="text-slate-300">Set con medallas de santos y cruces ornamentadas</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Set Cadenas Figaro Premium */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-08-29%20a%20las%2017.20.53_d6cbadc9.jpg-Bm4yZ7GnGLgDNjZMFEOUIEEIMvFTP4.jpeg"
                      alt="Set Cadenas Figaro Premium"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Set Cadenas Figaro Premium</h3>
                      <p className="text-slate-300">Cadenas tipo Figaro con múltiples dijes religiosos y cruces</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Cadenas con Medallas Mexicanas */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-08-29%20a%20las%2017.20.53_5c049c8e.jpg-LcgyMyF67vsgiKGiMMl7YvhgttHFjz.jpeg"
                      alt="Cadenas con Medallas Mexicanas"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Cadenas Medallas Mexicanas</h3>
                      <p className="text-slate-300">Set con medallas de la bandera mexicana y santos patrones</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡12,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-12">
              <Button
                size="lg"
                className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-1 transition-all duration-300 shadow-xl hover:shadow-amber-500/50"
              >
                <Sparkles className="h-5 w-5 mr-2" />
                Ver Toda la Colección Baño en Oro 18K
              </Button>
            </div>
          </div>
        </section>

        {/* Rosarios Section */}
        <section id="rosarios" className="py-20 bg-slate-800/30">
          <div className="container mx-auto px-4">
            <div className="text-center space-y-4 mb-16">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Cross className="h-8 w-8 text-amber-400 animate-pulse" />
                <Badge className="bg-amber-500 text-slate-900 text-lg px-4 py-2 font-semibold animate-pulse">
                  Colección Espiritual
                </Badge>
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold text-white text-balance">Rosarios en Oro Laminado</h2>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto text-pretty">
                Descubre nuestra exclusiva colección de rosarios y collares religiosos en oro laminado. Cada pieza
                combina fe, elegancia y calidad excepcional.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Rosario con Medalla Rectangular */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/rosario-medalla-rectangular-oro-laminado.jpg"
                      alt="Rosario con Medalla Rectangular"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Rosario Medalla Rectangular</h3>
                      <p className="text-slate-300">
                        Rosario con cuentas de perla y medalla rectangular en oro laminado
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡9,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rosario Simple con Cruz */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/rosario-clasico-cruz-oro-laminado.jpg"
                      alt="Rosario Simple con Cruz"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Rosario Clásico</h3>
                      <p className="text-slate-300">Rosario tradicional con cadena dorada y cruz en oro laminado</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡9,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rosario Minimalista */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/rosario-minimalista-oro-laminado.jpg"
                      alt="Rosario Minimalista"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Rosario Minimalista</h3>
                      <p className="text-slate-300">Diseño elegante y discreto con cadena fina en oro laminado</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡9,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rosario con Virgen */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/rosario-virgen-maria-oro-laminado.jpg"
                      alt="Rosario con Virgen"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Rosario Virgen María</h3>
                      <p className="text-slate-300">Rosario con figura de la Virgen María en oro laminado</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡9,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rosario con Cruz Ornamentada */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/rosario-cruz-ornamentada-oro-laminado.jpg"
                      alt="Rosario con Cruz Ornamentada"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Rosario Cruz Ornamentada</h3>
                      <p className="text-slate-300">Rosario con medalla circular y cruz ornamentada en oro laminado</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡9,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rosarios Dobles */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="/set-rosarios-dobles-oro-laminado.jpg"
                      alt="Rosarios Dobles"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Set Rosarios Dobles</h3>
                      <p className="text-slate-300">Conjunto de rosarios negro y azul con detalles en oro laminado</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡9,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-12">
              <Button
                size="lg"
                className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-1 transition-all duration-300 shadow-xl hover:shadow-amber-500/50"
              >
                <Cross className="h-5 w-5 mr-2" />
                Ver Toda la Colección de Rosarios
              </Button>
            </div>
          </div>
        </section>

        {/* Relojes Section */}
        <section id="relojes" className="py-20 bg-slate-800/50">
          <div className="container mx-auto px-4">
            <div className="text-center space-y-4 mb-16">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Watch className="h-8 w-8 text-amber-400 animate-pulse" />
                <Badge className="bg-amber-500 text-slate-900 text-lg px-4 py-2 animate-pulse">
                  Colección Exclusiva
                </Badge>
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold text-white text-balance">Relojes Rolex Premium</h2>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto text-pretty">
                Descubre nuestra exclusiva selección de relojes Rolex. Cada pieza representa la máxima expresión de lujo
                y precisión suiza.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Rolex Submariner Negro con Diamantes */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-09-02%20a%20las%2017.34.13_b3c8147d.jpg-qCzjNsMcLKJZ1Mx74M2HfdHxdBwVfZ.jpeg"
                      alt="Rolex Submariner Negro con Diamantes"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Submariner Black Diamond</h3>
                      <p className="text-slate-300">Rolex Submariner en oro con bisel de diamantes y esfera negra</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡32,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rolex Datejust Gris */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-09-02%20a%20las%2017.34.14_232e239f.jpg-GGhqqeVoXFIWIoRH22AwBx1lNfbyEI.jpeg"
                      alt="Rolex Datejust Gris con Diamantes"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Datejust Diamond Bezel</h3>
                      <p className="text-slate-300">Rolex Datejust en oro con esfera gris y bisel de diamantes</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡32,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rolex Datejust Bicolor */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-09-02%20a%20las%2017.34.14_e13b9ac8.jpg-JHZjAggLuiTuTya8aPjnJgo3HIB3Qy.jpeg"
                      alt="Rolex Datejust Bicolor"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Datejust Two-Tone</h3>
                      <p className="text-slate-300">Rolex Datejust bicolor oro y acero con bisel de diamantes</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡32,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rolex Submariner Dorado */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-09-02%20a%20las%2017.34.14_4b48e759.jpg-DAytVmQmb4v3B6Jkk6Pgbns3D8gr7V.jpeg"
                      alt="Rolex Submariner Dorado"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Submariner Full Gold</h3>
                      <p className="text-slate-300">Rolex Submariner completamente en oro 18K con esfera dorada</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡32,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rolex Submariner Cronógrafo */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-09-02%20a%20las%2017.34.14_9f87ac1a.jpg-OgvIfFtxelH0P730TSg5ahkMxSobtI.jpeg"
                      alt="Rolex Submariner Cronógrafo"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Submariner Chronograph</h3>
                      <p className="text-slate-300">Rolex Submariner dorado con función cronógrafo y bisel negro</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡32,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rolex Submariner Azul */}
              <Card className="group hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-500 border-slate-700 bg-slate-800/60 backdrop-blur-sm overflow-hidden transform hover:scale-105">
                <CardContent className="p-0">
                  <div className="aspect-square bg-gradient-to-br from-slate-700/50 to-slate-800/50 overflow-hidden">
                    <img
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagen%20de%20WhatsApp%202025-09-02%20a%20las%2017.34.13_0255ba71.jpg-2PZH2Ac41GeLgq9hSccJipFiyzr1x1.jpeg"
                      alt="Rolex Submariner Azul"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold text-white">Submariner Blue Diamond</h3>
                      <p className="text-slate-300">Rolex Submariner oro con esfera azul y bisel de diamantes</p>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-amber-400">₡32,500</span>
                        <Button
                          size="sm"
                          className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg"
                          onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                        >
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-12">
              <Button
                size="lg"
                className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-1 transition-all duration-300 shadow-xl hover:shadow-amber-500/50"
              >
                <Watch className="h-5 w-5 mr-2" />
                Ver Toda la Colección Rolex
              </Button>
            </div>
          </div>
        </section>

        {/* Pulsos y Pulseras Section */}
        <section id="pulsos-pulseras" className="py-20 bg-slate-800/50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <Badge className="bg-amber-500/20 text-amber-400 border-amber-400/30 mb-4">
                Pulsos y Pulseras Premium
              </Badge>
              <h2 className="text-3xl lg:text-5xl font-bold text-white mb-6 text-balance">
                Colección de Pulsos y Pulseras
              </h2>
              <p className="text-xl text-slate-300 max-w-3xl mx-auto text-pretty">
                Descubre nuestra exclusiva selección de pulseras y pulsos en oro, desde elegantes diseños con dijes
                coloridos hasta robustas cadenas cubanas. Cada pieza combina artesanía excepcional con estilo
                contemporáneo.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Pulseras con Dijes Coloridos */}
              <Card className="bg-slate-800/80 border-slate-700 hover:border-amber-400/50 transition-all duration-300 group overflow-hidden">
                <div className="relative overflow-hidden">
                  <img
                    src="/pulseras-dijes-coloridos-trebol.jpg"
                    alt="Pulseras con dijes coloridos estilo trébol"
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-white mb-2">Pulseras Dijes Coloridos</h3>
                  <p className="text-slate-300 mb-4">Elegantes pulseras con dijes tipo trébol en colores vibrantes</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-amber-400">₡5,000 - ₡8,500</span>
                    <Button
                      size="sm"
                      className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300"
                      onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                    >
                      Comprar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Pulseras Religiosas Delicadas */}
              <Card className="bg-slate-800/80 border-slate-700 hover:border-amber-400/50 transition-all duration-300 group overflow-hidden">
                <div className="relative overflow-hidden">
                  <img
                    src="/pulseras-religiosas-delicadas.jpg"
                    alt="Pulseras religiosas delicadas con dijes santos"
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-white mb-2">Pulseras Religiosas</h3>
                  <p className="text-slate-300 mb-4">Delicadas pulseras con dijes religiosos y santos protectores</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-amber-400">₡5,000 - ₡7,500</span>
                    <Button
                      size="sm"
                      className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300"
                      onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                    >
                      Comprar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Pulseras Cubanas Clásicas */}
              <Card className="bg-slate-800/80 border-slate-700 hover:border-amber-400/50 transition-all duration-300 group overflow-hidden">
                <div className="relative overflow-hidden">
                  <img
                    src="/pulseras-cubanas-clasicas-oro.jpg"
                    alt="Pulseras cubanas clásicas en oro"
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-white mb-2">Pulseras Cubanas Clásicas</h3>
                  <p className="text-slate-300 mb-4">Robustas pulseras cubanas con cierres de seguridad premium</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-amber-400">₡9,000 - ₡13,000</span>
                    <Button
                      size="sm"
                      className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300"
                      onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                    >
                      Comprar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Pulseras Premium con Cruz */}
              <Card className="bg-slate-800/80 border-slate-700 hover:border-amber-400/50 transition-all duration-300 group overflow-hidden">
                <div className="relative overflow-hidden">
                  <img
                    src="/pulseras-premium-cruz-diamantes.jpg"
                    alt="Pulseras premium con cruz de diamantes"
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-white mb-2">Pulseras Premium Cruz</h3>
                  <p className="text-slate-300 mb-4">
                    Exclusivas pulseras con cruces de diamantes y elementos religiosos
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-amber-400">₡10,000 - ₡13,000</span>
                    <Button
                      size="sm"
                      className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300"
                      onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                    >
                      Comprar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Pulseras Cubanas Variadas */}
              <Card className="bg-slate-800/80 border-slate-700 hover:border-amber-400/50 transition-all duration-300 group overflow-hidden">
                <div className="relative overflow-hidden">
                  <img
                    src="/pulseras-cubanas-variadas-grosores.jpg"
                    alt="Pulseras cubanas de diferentes grosores"
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-white mb-2">Pulseras Cubanas Variadas</h3>
                  <p className="text-slate-300 mb-4">Amplia selección de pulseras cubanas en diferentes grosores</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-amber-400">₡8,000 - ₡12,000</span>
                    <Button
                      size="sm"
                      className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300"
                      onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                    >
                      Comprar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Set Completo de Pulseras */}
              <Card className="bg-slate-800/80 border-slate-700 hover:border-amber-400/50 transition-all duration-300 group overflow-hidden">
                <div className="relative overflow-hidden">
                  <img
                    src="/set-completo-pulseras-mixtas.jpg"
                    alt="Set completo de pulseras mixtas"
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-white mb-2">Set Completo Mixto</h3>
                  <p className="text-slate-300 mb-4">Colección completa con pulseras de diferentes estilos y diseños</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-amber-400">₡7,000 - ₡11,000</span>
                    <Button
                      size="sm"
                      className="bg-amber-500 hover:bg-amber-400 text-slate-900 transform hover:scale-110 hover:rotate-3 transition-all duration-300"
                      onClick={() => document.getElementById("medios-pago")?.scrollIntoView({ behavior: "smooth" })}
                    >
                      Comprar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Features de Pulseras */}
            <div className="mt-16 grid md:grid-cols-3 gap-8">
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto">
                  <Sparkles className="w-8 h-8 text-amber-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Materiales Premium</h3>
                <p className="text-slate-300">Oro de alta calidad y elementos decorativos duraderos</p>
              </div>
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto">
                  <Shield className="w-8 h-8 text-amber-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Cierres Seguros</h3>
                <p className="text-slate-300">Sistemas de cierre confiables para uso diario</p>
              </div>
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto">
                  <Crown className="w-8 h-8 text-amber-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Diseños Únicos</h3>
                <p className="text-slate-300">Estilos exclusivos desde clásicos hasta contemporáneos</p>
              </div>
            </div>
          </div>
        </section>

        {/* Payment Methods Section */}
        <section className="py-16 bg-slate-800/30">
          <div className="container mx-auto px-4">
            <div className="text-center space-y-4 mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-white text-balance">Medios de Pago</h2>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto text-pretty">
                Facilitamos tu compra con métodos de pago seguros y convenientes
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {/* SINPE Móvil */}
              <Card className="bg-slate-800/60 border-slate-700 p-8 text-center">
                <div className="space-y-6">
                  <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-2xl">📱</span>
                  </div>
                  <h3 className="text-2xl font-semibold text-white">SINPE Móvil</h3>
                  <div className="space-y-4">
                    <div className="bg-slate-700/50 rounded-lg p-4">
                      <p className="text-amber-400 font-semibold text-lg">6083-7998</p>
                      <p className="text-amber-400 font-semibold text-lg">6193-5005</p>
                    </div>
                    <p className="text-slate-300">
                      Realiza tu transferencia y envía la captura de pantalla vía WhatsApp
                    </p>
                    <Button
                      className="bg-green-600 hover:bg-green-500 text-white w-full"
                      onClick={() => window.open("https://wa.me/50661182233", "_blank")}
                    >
                      WhatsApp: 6118-2233
                    </Button>
                  </div>
                </div>
              </Card>

              {/* Efectivo */}
              <Card className="bg-slate-800/60 border-slate-700 p-8 text-center">
                <div className="space-y-6">
                  <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-2xl">💵</span>
                  </div>
                  <h3 className="text-2xl font-semibold text-white">Efectivo</h3>
                  <div className="space-y-4">
                    <p className="text-slate-300">Pago en efectivo disponible para entregas locales</p>
                    <div className="bg-slate-700/50 rounded-lg p-4">
                      <p className="text-amber-400 font-semibold">Coordina tu entrega</p>
                      <p className="text-slate-300">Contacta por WhatsApp para coordinar</p>
                    </div>
                    <div className="bg-green-500/20 rounded-lg p-4">
                      <p className="text-green-400 font-semibold">WhatsApp: 6118-2233</p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-amber-500/10 via-amber-400/10 to-amber-500/10">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-3xl mx-auto space-y-8">
              <h2 className="text-3xl lg:text-4xl font-bold text-white text-balance">¿Listo para Elevar tu Estilo?</h2>
              <p className="text-xl text-slate-300 text-pretty">
                Únete a cientos de hombres que ya confían en SHANY SHAINS para sus accesorios de lujo, relojes Rolex,
                rosarios en oro laminado y nuestra exclusiva línea de baño en oro 18K. Calidad garantizada y estilo
                incomparable.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold transform hover:scale-110 hover:rotate-1 transition-all duration-300 shadow-xl hover:shadow-amber-500/50"
                >
                  Contactar por WhatsApp
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-slate-900 border-t border-slate-700 py-12">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-4 gap-8">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Crown className="h-6 w-6 text-amber-400" />
                  <span className="text-xl font-bold text-white">SHANY SHAINS</span>
                </div>
                <p className="text-slate-300">
                  Tu destino para joyería masculina de lujo, relojes Rolex, rosarios en oro laminado y accesorios
                  premium.
                </p>
              </div>
              <div className="space-y-4">
                <h4 className="font-semibold text-white">Productos</h4>
                <ul className="space-y-2 text-slate-300">
                  <li>
                    <a href="#" className="hover:text-amber-400 transition-colors">
                      Cadenas de Oro
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-400 transition-colors">
                      Pulseras
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-400 transition-colors">
                      Gorras Premium
                    </a>
                  </li>
                  <li>
                    <a href="#relojes" className="hover:text-amber-400 transition-colors">
                      Relojes Rolex
                    </a>
                  </li>
                  <li>
                    <a href="#rosarios" className="hover:text-amber-400 transition-colors">
                      Rosarios Oro Laminado
                    </a>
                  </li>
                </ul>
              </div>
              <div className="space-y-4">
                <h4 className="font-semibold text-white">Empresa</h4>
                <ul className="space-y-2 text-slate-300">
                  <li>
                    <a href="#" className="hover:text-amber-400 transition-colors">
                      Sobre Nosotros
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-400 transition-colors">
                      Garantía
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-400 transition-colors">
                      Envíos
                    </a>
                  </li>
                </ul>
              </div>
              <div className="space-y-4">
                <h4 className="font-semibold text-white">Contacto</h4>
                <ul className="space-y-2 text-slate-300">
                  <li>WhatsApp: 6118-2233</li>
                  <li>SINPE: 6083-7998 / 6193-5005</li>
                  <li>Horario: Lun-Sáb 9AM-8PM</li>
                </ul>
              </div>
            </div>
            <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-400">
              <p>&copy; 2024 SHANY SHAINS. Todos los derechos reservados.</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}
